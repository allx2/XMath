#include "Matrix/matrix.h"


int main(int argc,char *argv[])
{
    int Tiempo, EstadoInicial, EstadoFinal, Dimension;
    cout << "Caminata aleatoria"<<endl;
    cout << "periodos a calcular"<<endl;
    do
    {
        cin >> Tiempo;
    } while (Tiempo-1<0);


    cout << "Estado inicial:";
    do
    {
        cin >> EstadoInicial;
    } while (EstadoInicial<0);


    cout << "Estado final:";
    do
    {
        cin >> EstadoFinal;
    } while (EstadoFinal<0);

    cout << "Numero de estados(incluyendo el 0):";
    do
    {
        cin >> Dimension;
    } while (Dimension<0);


    matrix A(Dimension+1, Dimension+1);

    cout << "matriz de coeficientes:" << endl;
    cin >> A;

    const matrix B(Matrix_exp(A,Tiempo));

    cout << "La Probabilidad es:"<<B.Values(EstadoInicial, EstadoFinal)<<endl;
    system("pause");
    return 0;
}

