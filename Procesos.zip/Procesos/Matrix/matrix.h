#ifndef _MATRIX_
#define _MATRIX_

#include <iostream>
#include <cmath>
#include <istream>
#include <cstdlib>

using std::istream;
using std::ostream;
using std::cout;
using std::cin;
using std::endl;

class matrix{
private:
	float **M;
	int row, colum;
public:
	matrix();
	matrix(int, int);
	matrix(const matrix&);
	//sobrecarga de operadores
	matrix operator*( matrix&) ;
	matrix operator +(matrix&);
	const matrix &operator =(matrix&);

	friend istream& operator>>(istream&, matrix&);
	friend ostream& operator<<(ostream&, matrix&);

	//funcion potencia �SOLO POTENCIAS POSITIVAS ENTERAS! luego arreglo eso

	friend matrix Matrix_exp( matrix&,int);
	float Values(int, int)const ;
	~matrix();

};

#endif